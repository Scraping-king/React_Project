import React, { useEffect, useState } from "react";

function UseEffect() {
  const [counter, counterUpdater] = useState(0);
  useEffect(() => {
    console.log(counter);
  }, []);
  return (
    <div>
      You clicked {counter} times{" "}
      <button onClick={() => counterUpdater(counter + 1)}>Increment</button>
    </div>
  );
}

export default UseEffect;
