import React, { useContext } from "react";
import { OwennerContext, ChannelContext, HabeshaContext } from "../App";
function UseContext() {
  const Owenner = useContext(OwennerContext);
  const Channel = useContext(ChannelContext);
  const Habesha = useContext(HabeshaContext);
  return (
    <div>
      {Owenner}-{Channel}-{Habesha}
    </div>
  );
}

export default UseContext;
