import React, { useEffect, useState } from "react";
import axios from "axios";

function DataFetching() {
  const [posts, setPosts] = useState([]);
  useEffect(() => {
    axios.get("http://jsonplaceholder.typicode.com/posts").then((res) => {
      console.log(res);
      setPosts(res.data);
    });
  }, []);
  return (
    <div>
      <ul>
        {posts.map((posts) => (
          <li key={posts.id}>{posts.title}</li>
        ))}
      </ul>
    </div>
  );
}

export default DataFetching;
