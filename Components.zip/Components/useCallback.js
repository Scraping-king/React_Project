import React, { useCallback, useState } from "react";
import Counter from "./Counter";
import Button from "./Button";
function UseCallback() {
  const [counter1, setCount1] = useState(0);
  const [counter2, setCount2] = useState(0);

  const increment1 = useCallback(() => {
    setCount1(counter1 + 1);
  }, [counter1]);
  const increment2 = useCallback(() => {
    setCount2(counter2 + 2);
  }, [counter2]);
  return (
    <div>
      <Counter text="count by 1:" count={counter1} />
      <button handleClick={increment1}>+1</button>

      <Counter text="count by 2:" count={counter2} />
      <button handleClick={increment2}>+2</button>
    </div>
  );
}
export default UseCallback;
