import react from "react";
const Functional_comp = () => {
  return <h1>This is functional component</h1>;
};
export default Functional_comp;
