import React, { Component } from "react";
import Button from "./Button";

class Forms extends Component {
  constructor(props) {
    super(props);

    this.state = {
      UserName: " ",
      Comment: " ",
      Tutorials: " ",
    };
  }
  UserNamehandler = (Event) => {
    this.setState({
      UserName: Event.target.value,
    });
  };
  Commenthandler = (Event) => {
    this.setState({
      Comment: Event.target.value,
    });
  };
  Listhandler = (Event) => {
    this.setState({
      Tutorials: Event.target.value,
    });
  };
  Submithandler = (Event) => {
    alert(
      `${this.state.UserName}``${this.state.Comment}``${this.state.Tutorials}`
    );
  };

  render() {
    return (
      <form onSubmit={this.Submithandler}>
        <div>
          <label>UserName:</label>
          <input
            type="text"
            value={this.state.UserName}
            onChange={this.UserNamehandler}
          />
        </div>
        <div>
          <label>Comment:</label>
          <textarea
            value={this.state.Comment}
            onChange={this.Commenthandler}
          ></textarea>
        </div>
        ;
        <div>
          <label>Tutorials:</label>
          <select value={this.state.Tutorials} onChange={this.Listhandler}>
            <option value="javascript">javascript</option>
            <option value="react">react</option>
            <option value="python">python</option>
            <option value="html">html</option>
          </select>
        </div>
        <Button type="Submit">Submit</Button>
      </form>
    );
  }
}

export default Forms;
