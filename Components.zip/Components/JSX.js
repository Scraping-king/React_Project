import React from "react";
const Wellcome = () => {
  //   return <h1>Wellcome to our channel</h1>;
  // };
  // export default Wellcome;
  return React.createElement(
    "div",
    { id: "Wellcome", className: "class_welc" },
    React.createElement("h1", null, "well come to dj technology")
  );
};
export default Wellcome;
