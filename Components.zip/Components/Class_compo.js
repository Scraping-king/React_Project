import react, { Component } from "react";
class Comp_func extends Component {
  render() {
    return <h1>this is class Component</h1>;
  }
}
export default Comp_func;
