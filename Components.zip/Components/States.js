import React, { Component } from "react";

class States extends Component {
  constructor(props) {
    super(props);

    this.state = {
      Channel: "DJ Technology",
    };
  }
  //   function
  changeMessage() {
    this.setState({
      Channel: "ሰብስክራይብ ስላደረጉ እናመሰግናለን!",
    });
  }

  render() {
    return (
      <div>
        <h1>{this.state.Channel}</h1>
        <button onClick={() => this.changeMessage()}>ሰብስክራይብ</button>
      </div>
    );
  }
}

export default States;
