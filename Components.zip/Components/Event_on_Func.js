import React from "react";

function Event_Func() {
  function Handler() {
    // console.log("Clicked");
    alert("function on click");
  }
  return (
    <div>
      <button onClick={Handler}>Click me</button>
    </div>
  );
}

export default Event_Func;
