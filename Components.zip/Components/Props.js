import react from "react";
const FullName = (props) => {
  return (
    <h1>
      {props.name} Kebede Age={props.Age}
    </h1>
  );
};
export default FullName;

// import React, { Component } from "react";

// export default class Props extends Component {
//   render() {
//     return (
//       <div>
//         <h1>
//           {this.props.name} Kebede Age={this.props.Age}
//         </h1>
//       </div>
//     );
//   }
// }
