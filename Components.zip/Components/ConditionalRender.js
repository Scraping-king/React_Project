import React, { Component } from "react";

export class ConditionalRender extends Component {
  constructor(props) {
    super(props);

    this.state = {
      isSubscriber: true,
    };
  }

  render() {
    // #1 if--else
    if (this.state.isSubscriber) {
      return (
        <div>
          <h1>Subscribed</h1>
        </div>
      );
    } else {
      <div>
        <h1>Subscribe</h1>
      </div>;
    }
    // #2 Ternary operator
    // return this.state.isSubscriber ? (
    //   <div>
    //     <h1>Subcribed</h1>
    //   </div>
    // ) : (
    //   <div>
    //     <h1>Subcribe</h1>
    //   </div>
    // );
    // #3 Logical operator
    // render(
    //   this.state.isSubscriber && (
    //     <div>
    //       <h1>Subscribed</h1>
    //     </div>
    //   )
    // );
    // return (
    //   <div>
    //     <h1>Subscribe</h1>
    //     <h1>Subscribed</h1>
    //   </div>
    // );
  }
}

export default ConditionalRender;
