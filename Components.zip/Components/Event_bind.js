import React, { Component } from "react";

class Event_bind extends Component {
  constructor(props) {
    super(props);

    this.state = {
      msg: "GOOD BY!",
    };
    this.HANDLER = this.HANDLER.bind(this);
  }
  HANDLER() {
    this.setState({
      msg: "THANKS",
    });
  }
  render() {
    return (
      <div>
        <h1>{this.state.msg}</h1>
        {/* <button onClick={this.HANDLER.bind(this)}>click</button> */}
        {/* <button onClick={() => this.HANDLER()}>click</button> */}
        <button onClick={this.HANDLER}>click</button>
      </div>
    );
  }
}

export default Event_bind;
