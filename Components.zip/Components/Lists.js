import React from "react";

function Programming() {
  const Prog = ["c++", "java", "python", "python"];
  return (
    <div>
      {Prog.map((name, index) => (
        <h1 key={index}>
          <li type="square">{name}</li>
        </h1>
      ))}
    </div>
  );
}
export default Programming;
