import React from "react";

function UseMemo() {
  return <div>UseMemo</div>;
}

export default UseMemo;
